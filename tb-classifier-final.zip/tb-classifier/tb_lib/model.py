"""TensorFlow model loading — the only module that imports TF.

Isolated here so the rest of tb_lib stays TF-free and CI-testable. The
model is loaded lazily and cached; the serving layers call
`get_predict_fn()` to obtain a `predict_fn` compatible with
tb_lib.predict.
"""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path

import numpy as np

from .config import MODEL_PATH
from .predict import PredictFn


class ModelNotFoundError(FileNotFoundError):
    """Raised when the trained model file is missing."""


@lru_cache(maxsize=1)
def load_model(model_path: str | Path = MODEL_PATH):
    """Load and cache the Keras model. Imports TF lazily."""
    path = Path(model_path)
    if not path.exists():
        raise ModelNotFoundError(
            f"No trained model at {path}. Train one with "
            f"`python scripts/train.py --data <dataset_dir>` first."
        )
    from tensorflow import keras  # lazy: keeps import cost out of CI
    return keras.models.load_model(path)


def get_predict_fn(model_path: str | Path = MODEL_PATH) -> PredictFn:
    """Return a predict_fn(batch, training) for MC-dropout inference."""
    model = load_model(model_path)

    def predict_fn(batch: np.ndarray, training: bool = False) -> np.ndarray:
        # training=True keeps dropout active -> stochastic pass
        return model(batch, training=training).numpy()

    return predict_fn
