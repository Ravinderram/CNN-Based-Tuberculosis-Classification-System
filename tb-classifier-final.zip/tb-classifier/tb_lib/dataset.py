"""Dataset auto-splitting.

Turns a single folder of class subdirectories into a reproducible,
stratified train/val/test split — so the user only ever pastes ONE path.

Input layout (what Kaggle's TB Chest Radiography Database gives you):

    <root>/
        Normal/         *.png
        Tuberculosis/   *.png

The split is:
  * stratified — each class keeps its proportion in every split;
  * reproducible — fixed seed, so reruns give the same split;
  * leakage-free — a file lands in exactly one split.

Two modes:
  * plan_split()  — pure function returning which files go where.
                    No filesystem writes, fully unit-tested.
  * materialize_split() — actually copies files into train/val/test
                    dirs for Keras' flow_from_directory.
"""
from __future__ import annotations

import shutil
from dataclasses import dataclass, field
from pathlib import Path

IMAGE_EXTS = frozenset({".png", ".jpg", ".jpeg", ".bmp"})


@dataclass(frozen=True)
class SplitPlan:
    """Which files go into each split, per class."""
    train: dict[str, list[Path]] = field(default_factory=dict)
    valid: dict[str, list[Path]] = field(default_factory=dict)
    test: dict[str, list[Path]] = field(default_factory=dict)

    def counts(self) -> dict[str, dict[str, int]]:
        return {
            "train": {c: len(f) for c, f in self.train.items()},
            "valid": {c: len(f) for c, f in self.valid.items()},
            "test": {c: len(f) for c, f in self.test.items()},
        }

    def total(self) -> int:
        return sum(
            len(f)
            for split in (self.train, self.valid, self.test)
            for f in split.values()
        )


def find_classes(root: str | Path) -> dict[str, list[Path]]:
    """Discover class subfolders and their image files under root."""
    root = Path(root)
    if not root.is_dir():
        raise NotADirectoryError(f"{root} is not a directory.")

    classes: dict[str, list[Path]] = {}
    for sub in sorted(p for p in root.iterdir() if p.is_dir()):
        images = sorted(
            p for p in sub.iterdir()
            if p.is_file() and p.suffix.lower() in IMAGE_EXTS
        )
        if images:
            classes[sub.name] = images

    if len(classes) < 2:
        raise ValueError(
            f"Expected >= 2 class subfolders with images under {root}. "
            f"Found: {list(classes)}. Layout should be "
            f"<root>/Normal/*.png and <root>/Tuberculosis/*.png."
        )
    return classes


def plan_split(
    classes: dict[str, list[Path]],
    val_frac: float = 0.15,
    test_frac: float = 0.15,
    seed: int = 42,
) -> SplitPlan:
    """Stratified split planner — pure, deterministic, no I/O.

    Shuffles each class independently with a fixed seed, then slices.
    """
    if not 0 < val_frac < 1 or not 0 < test_frac < 1:
        raise ValueError("val_frac and test_frac must be in (0, 1).")
    if val_frac + test_frac >= 1.0:
        raise ValueError("val_frac + test_frac must be < 1.0.")

    import random

    train, valid, test = {}, {}, {}
    for cls, files in classes.items():
        files = list(files)
        random.Random(seed).shuffle(files)  # per-class, seeded
        n = len(files)
        n_test = int(n * test_frac)
        n_val = int(n * val_frac)
        test[cls] = files[:n_test]
        valid[cls] = files[n_test:n_test + n_val]
        train[cls] = files[n_test + n_val:]
    return SplitPlan(train=train, valid=valid, test=test)


def materialize_split(
    plan: SplitPlan,
    out_dir: str | Path,
    move: bool = False,
    overwrite: bool = False,
) -> Path:
    """Copy (or move) files into out_dir/{train,valid,test}/<class>/.

    Returns the output directory, ready for flow_from_directory.
    """
    out = Path(out_dir)
    if out.exists() and any(out.iterdir()) and not overwrite:
        raise FileExistsError(
            f"{out} already exists and is not empty. "
            f"Pass overwrite=True to replace it."
        )
    if out.exists() and overwrite:
        shutil.rmtree(out)

    op = shutil.move if move else shutil.copy2
    for split_name, split in (("train", plan.train),
                              ("valid", plan.valid),
                              ("test", plan.test)):
        for cls, files in split.items():
            dest_dir = out / split_name / cls
            dest_dir.mkdir(parents=True, exist_ok=True)
            for src in files:
                op(str(src), str(dest_dir / src.name))
    return out


def auto_split(
    root: str | Path,
    out_dir: str | Path,
    val_frac: float = 0.15,
    test_frac: float = 0.15,
    seed: int = 42,
    move: bool = False,
    overwrite: bool = False,
) -> tuple[Path, SplitPlan]:
    """One call: discover classes, plan the split, write it out.

    Returns (output_dir, plan). The user only supplies `root`.
    """
    classes = find_classes(root)
    plan = plan_split(classes, val_frac, test_frac, seed)
    out = materialize_split(plan, out_dir, move=move, overwrite=overwrite)
    return out, plan
