"""Model architecture — MobileNetV2 transfer learning.

Rationale for the upgrade over the original from-scratch CNN:
  * The original 3-conv net trained from scratch on a small dataset
    overfits easily and wastes the signal in ImageNet features.
  * MobileNetV2 pretrained on ImageNet gives strong low-level features
    for free; we only train a small head. Faster, more accurate, less data.
  * A Dropout layer before the output stays active at inference for
    Monte-Carlo dropout uncertainty (see tb_lib/predict.py).

Import TF lazily so this file can be imported for reference without the
heavy dependency.
"""
from __future__ import annotations

from tb_lib.config import CHANNELS, IMG_SIZE


def build_model(dropout_rate: float = 0.3, fine_tune: bool = False):
    """Return a compiled Keras model for binary TB classification."""
    import tensorflow as tf
    from tensorflow.keras import layers, models
    from tensorflow.keras.applications import MobileNetV2

    base = MobileNetV2(
        input_shape=(*IMG_SIZE, CHANNELS),
        include_top=False,
        weights="imagenet",
    )
    base.trainable = fine_tune  # frozen first pass; optionally fine-tune later

    model = models.Sequential([
        layers.Input(shape=(*IMG_SIZE, CHANNELS)),
        base,
        layers.GlobalAveragePooling2D(),
        layers.Dense(128, activation="relu"),
        layers.Dropout(dropout_rate),     # kept ON at inference for MC-dropout
        layers.Dense(1, activation="sigmoid"),
    ])
    model.compile(
        optimizer=tf.keras.optimizers.Adam(1e-4 if fine_tune else 1e-3),
        loss="binary_crossentropy",
        metrics=["accuracy",
                 tf.keras.metrics.Precision(name="precision"),
                 tf.keras.metrics.Recall(name="recall"),
                 tf.keras.metrics.AUC(name="auc")],
    )
    return model
