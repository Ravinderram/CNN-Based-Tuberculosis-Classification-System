"""Prediction with honest uncertainty via Monte-Carlo dropout.

Key design choice: the statistics here operate on a `predict_fn` — any
callable that maps a batch array to sigmoid outputs. The real TF model is
one such callable, but tests inject a fake one, so all the uncertainty
math is verified in CI without TensorFlow.

Monte-Carlo dropout (Gal & Ghahramani, 2016): keep dropout active at
inference and run N stochastic forward passes. The spread of the outputs
approximates the model's epistemic uncertainty — far more honest than the
original project's single bare sigmoid score.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import numpy as np

from .config import (
    CLASS_NAMES, DEFAULT_THRESHOLD, DISCLAIMER, MC_DROPOUT_SAMPLES,
)

# A predict_fn takes (batch, training_flag) -> array of shape (batch, 1)
PredictFn = Callable[[np.ndarray, bool], np.ndarray]


@dataclass(frozen=True)
class Prediction:
    label: str
    probability: float           # P(TB), point estimate (mean over MC samples)
    confidence: float            # max(p, 1-p) — how far from the 0.5 fence
    uncertainty_std: float       # std of MC-dropout samples
    ci_low: float                # 95% credible-ish interval on P(TB)
    ci_high: float
    threshold: float
    n_samples: int
    disclaimer: str = DISCLAIMER

    def as_dict(self) -> dict:
        return {
            "label": self.label,
            "probability": round(self.probability, 4),
            "confidence": round(self.confidence, 4),
            "uncertainty_std": round(self.uncertainty_std, 4),
            "credible_interval": [round(self.ci_low, 4), round(self.ci_high, 4)],
            "threshold": self.threshold,
            "mc_samples": self.n_samples,
            "disclaimer": self.disclaimer,
        }


def predict_single(
    predict_fn: PredictFn,
    batch: np.ndarray,
    threshold: float = DEFAULT_THRESHOLD,
    mc_samples: int = MC_DROPOUT_SAMPLES,
) -> Prediction:
    """Run MC-dropout inference on one preprocessed image (batch size 1)."""
    if not 0.0 < threshold < 1.0:
        raise ValueError("threshold must be in (0, 1).")
    if mc_samples < 1:
        raise ValueError("mc_samples must be >= 1.")

    # N stochastic passes with dropout ON (training=True)
    samples = np.array(
        [float(predict_fn(batch, True).ravel()[0]) for _ in range(mc_samples)]
    )
    samples = np.clip(samples, 0.0, 1.0)

    p = float(samples.mean())
    std = float(samples.std())
    lo, hi = np.quantile(samples, [0.025, 0.975])

    label = CLASS_NAMES[1] if p >= threshold else CLASS_NAMES[0]
    confidence = max(p, 1.0 - p)

    return Prediction(
        label=label,
        probability=p,
        confidence=confidence,
        uncertainty_std=std,
        ci_low=float(lo),
        ci_high=float(hi),
        threshold=threshold,
        n_samples=mc_samples,
    )


def interpret_uncertainty(pred: Prediction, high_std: float = 0.15) -> str:
    """A plain-language reliability note based on the MC spread."""
    if pred.uncertainty_std >= high_std:
        return ("High model uncertainty on this image — the prediction is "
                "unreliable. A different or clearer X-ray is recommended.")
    if pred.confidence < 0.65:
        return ("Borderline case near the decision threshold; treat the "
                "result with caution.")
    return "Model is relatively consistent across stochastic passes."
