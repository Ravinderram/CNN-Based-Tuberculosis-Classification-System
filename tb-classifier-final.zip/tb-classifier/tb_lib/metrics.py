"""Classification metrics — pure numpy, no sklearn/TF.

For a classifier, these numbers are the deliverable. The original project
reported only a single training-accuracy print; a portfolio-grade version
needs precision, recall, specificity, F1, and ROC-AUC on a held-out set,
plus a threshold sweep (accuracy alone is misleading under class
imbalance, which is common in medical screening data).
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True)
class ConfusionMatrix:
    tp: int
    fp: int
    tn: int
    fn: int

    @property
    def accuracy(self) -> float:
        total = self.tp + self.fp + self.tn + self.fn
        return (self.tp + self.tn) / total if total else 0.0

    @property
    def precision(self) -> float:
        denom = self.tp + self.fp
        return self.tp / denom if denom else 0.0

    @property
    def recall(self) -> float:              # sensitivity / true-positive rate
        denom = self.tp + self.fn
        return self.tp / denom if denom else 0.0

    @property
    def specificity(self) -> float:         # true-negative rate
        denom = self.tn + self.fp
        return self.tn / denom if denom else 0.0

    @property
    def f1(self) -> float:
        p, r = self.precision, self.recall
        return 2 * p * r / (p + r) if (p + r) else 0.0

    def as_dict(self) -> dict:
        return {
            "confusion_matrix": {"tp": self.tp, "fp": self.fp,
                                 "tn": self.tn, "fn": self.fn},
            "accuracy": round(self.accuracy, 4),
            "precision": round(self.precision, 4),
            "recall_sensitivity": round(self.recall, 4),
            "specificity": round(self.specificity, 4),
            "f1": round(self.f1, 4),
        }


def confusion_matrix(y_true: np.ndarray, y_prob: np.ndarray,
                     threshold: float = 0.5) -> ConfusionMatrix:
    """Binary confusion matrix at a given probability threshold.

    y_true: 0/1 labels (1 = TB). y_prob: P(TB) in [0, 1].
    """
    y_true = np.asarray(y_true).astype(int)
    y_pred = (np.asarray(y_prob) >= threshold).astype(int)
    tp = int(np.sum((y_pred == 1) & (y_true == 1)))
    fp = int(np.sum((y_pred == 1) & (y_true == 0)))
    tn = int(np.sum((y_pred == 0) & (y_true == 0)))
    fn = int(np.sum((y_pred == 0) & (y_true == 1)))
    return ConfusionMatrix(tp, fp, tn, fn)


def roc_curve(y_true: np.ndarray, y_prob: np.ndarray
              ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Return (fpr, tpr, thresholds). Thresholds are the unique scores."""
    y_true = np.asarray(y_true).astype(int)
    y_prob = np.asarray(y_prob, dtype=float)
    order = np.argsort(-y_prob)
    y_true = y_true[order]
    y_prob = y_prob[order]

    P = max(int(y_true.sum()), 1)
    N = max(int((1 - y_true).sum()), 1)

    tps = np.cumsum(y_true)
    fps = np.cumsum(1 - y_true)
    # prepend the (0,0) origin
    tpr = np.concatenate([[0.0], tps / P])
    fpr = np.concatenate([[0.0], fps / N])
    thr = np.concatenate([[np.inf], y_prob])
    return fpr, tpr, thr


def roc_auc(y_true: np.ndarray, y_prob: np.ndarray) -> float:
    """Area under the ROC curve via the trapezoidal rule."""
    fpr, tpr, _ = roc_curve(y_true, y_prob)
    return float(np.trapezoid(tpr, fpr))


def threshold_sweep(y_true: np.ndarray, y_prob: np.ndarray,
                    steps: int = 21) -> list[dict]:
    """Metrics across thresholds — for choosing an operating point."""
    out = []
    for t in np.linspace(0.0, 1.0, steps):
        cm = confusion_matrix(y_true, y_prob, threshold=float(t))
        row = {"threshold": round(float(t), 3)}
        row.update(cm.as_dict())
        out.append(row)
    return out


def best_threshold_for_sensitivity(y_true: np.ndarray, y_prob: np.ndarray,
                                   target_sensitivity: float = 0.90) -> float:
    """Lowest threshold achieving >= target recall — a screening-style rule.

    In TB screening you prioritise catching positives (high sensitivity),
    accepting more false positives, rather than defaulting to 0.5.
    """
    thresholds = np.linspace(0.0, 1.0, 101)
    best = 0.0
    for t in thresholds:
        cm = confusion_matrix(y_true, y_prob, threshold=float(t))
        if cm.recall >= target_sensitivity:
            best = float(t)
    return best
