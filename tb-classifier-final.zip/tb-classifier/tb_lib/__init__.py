"""CNN-based TB chest X-ray classifier — research/educational use only."""
from .config import (
    IMG_SIZE, CLASS_NAMES, POSITIVE_CLASS, DEFAULT_THRESHOLD,
    MODEL_PATH, DISCLAIMER,
)
from .preprocessing import (
    InvalidImageError, validate_upload, load_image, preprocess,
    preprocess_bytes, preprocess_path,
)
from .predict import (
    Prediction, predict_single, interpret_uncertainty, PredictFn,
)
from .metrics import (
    ConfusionMatrix, confusion_matrix, roc_curve, roc_auc,
    threshold_sweep, best_threshold_for_sensitivity,
)
from .gradcam import build_heatmap, overlay_heatmap
from .dataset import (
    find_classes, plan_split, materialize_split, auto_split, SplitPlan,
)

__all__ = [
    "IMG_SIZE", "CLASS_NAMES", "POSITIVE_CLASS", "DEFAULT_THRESHOLD",
    "MODEL_PATH", "DISCLAIMER",
    "InvalidImageError", "validate_upload", "load_image", "preprocess",
    "preprocess_bytes", "preprocess_path",
    "Prediction", "predict_single", "interpret_uncertainty", "PredictFn",
    "ConfusionMatrix", "confusion_matrix", "roc_curve", "roc_auc",
    "threshold_sweep", "best_threshold_for_sensitivity",
    "build_heatmap", "overlay_heatmap",
    "find_classes", "plan_split", "materialize_split", "auto_split",
    "SplitPlan",
]
