"""Grad-CAM explainability heatmaps.

Grad-CAM (Selvaraju et al., 2017) highlights the image regions that most
influenced the prediction. For a medical model this is essential: it
reveals whether the network attends to lung fields (good) or to text
markers, borders, or scanner artifacts (a model that "cheats" — a
notorious failure mode in chest-X-ray papers).

The heatmap construction (weight feature maps by pooled gradients, ReLU,
normalise) is pure numpy and unit-tested. The gradient extraction needs
TF and is isolated in `compute_gradcam`.
"""
from __future__ import annotations

import numpy as np


def build_heatmap(feature_maps: np.ndarray, gradients: np.ndarray) -> np.ndarray:
    """Core Grad-CAM math — no TF.

    Args:
        feature_maps: last conv activations, shape (H, W, C).
        gradients:    d(score)/d(feature_maps), same shape.
    Returns:
        Heatmap of shape (H, W), values in [0, 1].
    """
    if feature_maps.shape != gradients.shape:
        raise ValueError("feature_maps and gradients must have the same shape.")
    if feature_maps.ndim != 3:
        raise ValueError("expected (H, W, C) arrays.")

    # importance weight per channel = global-average-pooled gradient
    weights = gradients.mean(axis=(0, 1))              # (C,)
    cam = np.tensordot(feature_maps, weights, axes=([2], [0]))  # (H, W)
    cam = np.maximum(cam, 0)                            # ReLU: only positive
    peak = cam.max()
    if peak > 0:
        cam = cam / peak                               # normalise to [0, 1]
    return cam.astype(np.float32)


def overlay_heatmap(image: np.ndarray, heatmap: np.ndarray,
                    alpha: float = 0.4) -> np.ndarray:
    """Blend a [0,1] heatmap over an RGB image (both resized to match).

    Uses a simple red colormap to avoid a matplotlib dependency in the
    serving path. Returns uint8 RGB.
    """
    from PIL import Image

    if image.dtype != np.uint8:
        image = (np.clip(image, 0, 1) * 255).astype(np.uint8)
    h, w = image.shape[:2]
    hm = np.asarray(
        Image.fromarray((heatmap * 255).astype(np.uint8)).resize((w, h))
    ) / 255.0

    # red-hot overlay
    colored = np.zeros_like(image, dtype=np.float32)
    colored[..., 0] = hm * 255                     # red channel = intensity
    blended = (1 - alpha) * image + alpha * colored
    return np.clip(blended, 0, 255).astype(np.uint8)


def compute_gradcam(model, batch: np.ndarray, last_conv_layer: str | None = None):
    """Full Grad-CAM using a real Keras model. Imports TF lazily.

    Keras 3 compatible: rather than building a functional model from
    symbolic `.output` tensors (which a Sequential model does not expose
    until it has been symbolically called — the source of the
    "layer has never been called" error), this does a real eager forward
    pass, splitting the network at its convolutional feature extractor and
    watching that activation with a GradientTape.

    Returns (heatmap HxW in [0,1], predicted_probability).
    """
    import tensorflow as tf

    # Find the split point: the nested conv base (e.g. MobileNetV2, a
    # Functional sub-model) or, failing that, the last conv layer. Every
    # layer after it forms the classifier head.
    split_idx = None
    for i, layer in enumerate(model.layers):
        if isinstance(layer, tf.keras.Model) or \
                "conv" in layer.__class__.__name__.lower():
            split_idx = i  # keep the LAST match
    if split_idx is None:
        raise ValueError("No conv layer or nested model found for Grad-CAM.")

    feature_layer = model.layers[split_idx]
    head_layers = model.layers[split_idx + 1:]

    x = tf.convert_to_tensor(batch, dtype=tf.float32)
    with tf.GradientTape() as tape:
        conv_out = feature_layer(x, training=False)   # (1, H, W, C)
        tape.watch(conv_out)
        h = conv_out
        for layer in head_layers:                     # run the head eagerly
            h = layer(h, training=False)
        score = h[:, 0]
    grads = tape.gradient(score, conv_out)

    heatmap = build_heatmap(conv_out[0].numpy(), grads[0].numpy())
    return heatmap, float(h[0][0])
