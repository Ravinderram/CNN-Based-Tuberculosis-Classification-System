"""Image loading, validation, and preprocessing.

Deliberately depends only on Pillow + numpy (not TensorFlow), so this
whole module is unit-testable without the heavy ML stack and runs in CI.
The original code used cv2.imread with no validation — a corrupt or
non-image upload crashed the request.
"""
from __future__ import annotations

import io
from pathlib import Path

import numpy as np
from PIL import Image, UnidentifiedImageError

from .config import ALLOWED_EXTENSIONS, CHANNELS, IMG_SIZE, MAX_UPLOAD_BYTES


class InvalidImageError(ValueError):
    """Raised when an upload is missing, too large, or not a real image."""


def validate_upload(filename: str, data: bytes) -> None:
    """Cheap checks before we try to decode: extension + size."""
    ext = Path(filename).suffix.lower()
    if ext not in ALLOWED_EXTENSIONS:
        raise InvalidImageError(
            f"Unsupported file type {ext!r}. "
            f"Allowed: {', '.join(sorted(ALLOWED_EXTENSIONS))}."
        )
    if len(data) == 0:
        raise InvalidImageError("Uploaded file is empty.")
    if len(data) > MAX_UPLOAD_BYTES:
        raise InvalidImageError(
            f"File too large ({len(data)} bytes); "
            f"limit is {MAX_UPLOAD_BYTES} bytes."
        )


def load_image(data: bytes) -> Image.Image:
    """Decode bytes into an RGB PIL image, or raise InvalidImageError."""
    try:
        img = Image.open(io.BytesIO(data))
        img.verify()               # detect truncated/corrupt files
        img = Image.open(io.BytesIO(data))  # re-open: verify() exhausts it
        return img.convert("RGB")
    except (UnidentifiedImageError, OSError) as exc:
        raise InvalidImageError("File is not a readable image.") from exc


def preprocess(img: Image.Image) -> np.ndarray:
    """PIL image -> model-ready array of shape (1, H, W, C), scaled to [0, 1]."""
    img = img.convert("RGB").resize(IMG_SIZE, Image.BILINEAR)
    arr = np.asarray(img, dtype=np.float32) / 255.0
    if arr.shape != (*IMG_SIZE, CHANNELS):
        raise InvalidImageError(f"Unexpected image shape {arr.shape}.")
    return np.expand_dims(arr, axis=0)


def preprocess_bytes(filename: str, data: bytes) -> np.ndarray:
    """Full pipeline: validate -> decode -> preprocess."""
    validate_upload(filename, data)
    return preprocess(load_image(data))


def preprocess_path(path: str | Path) -> np.ndarray:
    """Convenience loader for local files (e.g. evaluation, tests)."""
    p = Path(path)
    data = p.read_bytes()
    return preprocess_bytes(p.name, data)
