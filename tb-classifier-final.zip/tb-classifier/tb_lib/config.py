"""Central configuration — single source of truth.

The original project had the image size hardcoded inconsistently (200 in
the notebook, 256 in the Flask app) and the model path wrong. Everything
now reads from here so the training script and the serving code can never
disagree.
"""
from __future__ import annotations

from pathlib import Path

# ---- image preprocessing ----
IMG_SIZE: tuple[int, int] = (224, 224)   # MobileNetV2 native size
CHANNELS: int = 3

# ---- classes ----
# Binary task. Index 1 = the positive (TB) class, so a sigmoid output is
# P(tuberculosis).
CLASS_NAMES: tuple[str, str] = ("Normal", "Tuberculosis")
POSITIVE_CLASS: str = "Tuberculosis"

# ---- decision threshold ----
# NOT fixed at 0.5. For a screening task you tune this on the validation
# set to hit a target sensitivity; see scripts/evaluate.py.
DEFAULT_THRESHOLD: float = 0.5

# ---- paths ----
PROJECT_ROOT: Path = Path(__file__).resolve().parent.parent
MODEL_PATH: Path = PROJECT_ROOT / "model" / "tb_model.keras"

# ---- upload safety ----
ALLOWED_EXTENSIONS: frozenset[str] = frozenset({".png", ".jpg", ".jpeg", ".bmp"})
MAX_UPLOAD_BYTES: int = 10 * 1024 * 1024   # 10 MB

# ---- MC-dropout ----
MC_DROPOUT_SAMPLES: int = 30

DISCLAIMER: str = (
    "Research and educational use only. This is NOT a medical device and "
    "must not be used for diagnosis or any clinical decision. Chest X-ray "
    "interpretation requires a qualified radiologist."
)
