"""Tests for dataset auto-splitting. Uses tiny synthetic PNG files."""
from pathlib import Path

import pytest
from PIL import Image

from tb_lib.dataset import (
    find_classes, plan_split, materialize_split, auto_split, SplitPlan,
)


def _make_dataset(root: Path, n_normal: int, n_tb: int) -> Path:
    """Create <root>/Normal/*.png and <root>/Tuberculosis/*.png."""
    for cls, n in [("Normal", n_normal), ("Tuberculosis", n_tb)]:
        d = root / cls
        d.mkdir(parents=True)
        for i in range(n):
            Image.new("RGB", (8, 8), (i % 255, 0, 0)).save(d / f"{cls}-{i}.png")
    return root


# ------------------------------------------------------------ discovery

def test_find_classes(tmp_path):
    _make_dataset(tmp_path, 10, 8)
    classes = find_classes(tmp_path)
    assert set(classes) == {"Normal", "Tuberculosis"}
    assert len(classes["Normal"]) == 10
    assert len(classes["Tuberculosis"]) == 8


def test_find_classes_ignores_non_images(tmp_path):
    _make_dataset(tmp_path, 3, 3)
    (tmp_path / "Normal" / "notes.txt").write_text("ignore me")
    assert len(find_classes(tmp_path)["Normal"]) == 3  # txt not counted


def test_find_classes_rejects_single_class(tmp_path):
    d = tmp_path / "Normal"
    d.mkdir(parents=True)
    Image.new("RGB", (8, 8)).save(d / "a.png")
    with pytest.raises(ValueError, match=">= 2 class"):
        find_classes(tmp_path)


def test_find_classes_rejects_missing_dir(tmp_path):
    with pytest.raises(NotADirectoryError):
        find_classes(tmp_path / "does_not_exist")


# --------------------------------------------------------------- planning

def test_plan_split_proportions():
    classes = {"Normal": [Path(f"n{i}.png") for i in range(100)],
               "Tuberculosis": [Path(f"t{i}.png") for i in range(100)]}
    plan = plan_split(classes, val_frac=0.15, test_frac=0.15, seed=1)
    c = plan.counts()
    assert c["test"]["Normal"] == 15
    assert c["valid"]["Normal"] == 15
    assert c["train"]["Normal"] == 70
    assert plan.total() == 200


def test_plan_split_is_stratified():
    classes = {"Normal": [Path(f"n{i}.png") for i in range(80)],
               "Tuberculosis": [Path(f"t{i}.png") for i in range(20)]}
    plan = plan_split(classes, seed=1)
    # each class keeps ~70/15/15 regardless of its size
    assert plan.counts()["train"]["Normal"] == 56
    assert plan.counts()["train"]["Tuberculosis"] == 14


def test_plan_split_no_leakage():
    classes = {"Normal": [Path(f"n{i}.png") for i in range(50)],
               "Tuberculosis": [Path(f"t{i}.png") for i in range(50)]}
    plan = plan_split(classes, seed=7)
    for cls in classes:
        allocated = (set(plan.train[cls]) | set(plan.valid[cls])
                     | set(plan.test[cls]))
        assert len(allocated) == 50  # every file used exactly once
        assert (len(plan.train[cls]) + len(plan.valid[cls])
                + len(plan.test[cls])) == 50


def test_plan_split_reproducible():
    classes = {"A": [Path(f"a{i}.png") for i in range(30)],
               "B": [Path(f"b{i}.png") for i in range(30)]}
    p1 = plan_split(classes, seed=123)
    p2 = plan_split(classes, seed=123)
    assert p1.train == p2.train and p1.test == p2.test


def test_plan_split_different_seeds_differ():
    classes = {"A": [Path(f"a{i}.png") for i in range(30)],
               "B": [Path(f"b{i}.png") for i in range(30)]}
    assert plan_split(classes, seed=1).train != plan_split(classes, seed=2).train


def test_plan_split_rejects_bad_fractions():
    classes = {"A": [Path("a.png")], "B": [Path("b.png")]}
    with pytest.raises(ValueError):
        plan_split(classes, val_frac=0.6, test_frac=0.6)


# ---------------------------------------------------------- materialize

def test_materialize_creates_layout(tmp_path):
    _make_dataset(tmp_path / "raw", 20, 20)
    classes = find_classes(tmp_path / "raw")
    plan = plan_split(classes, seed=3)
    out = materialize_split(plan, tmp_path / "split")
    for split in ("train", "valid", "test"):
        for cls in ("Normal", "Tuberculosis"):
            assert (out / split / cls).is_dir()
    # copy (default) leaves originals in place
    assert (tmp_path / "raw" / "Normal").exists()


def test_materialize_refuses_nonempty_without_overwrite(tmp_path):
    _make_dataset(tmp_path / "raw", 10, 10)
    plan = plan_split(find_classes(tmp_path / "raw"))
    materialize_split(plan, tmp_path / "split")
    with pytest.raises(FileExistsError):
        materialize_split(plan, tmp_path / "split")
    # overwrite succeeds
    materialize_split(plan, tmp_path / "split", overwrite=True)


# --------------------------------------------------------------- one-call

def test_auto_split_end_to_end(tmp_path):
    _make_dataset(tmp_path / "raw", 40, 30)
    out, plan = auto_split(tmp_path / "raw", tmp_path / "split", seed=5)
    assert plan.total() == 70
    # counts add up and files exist on disk
    n_train_files = sum(1 for _ in (out / "train").rglob("*.png"))
    n_val_files = sum(1 for _ in (out / "valid").rglob("*.png"))
    n_test_files = sum(1 for _ in (out / "test").rglob("*.png"))
    assert n_train_files + n_val_files + n_test_files == 70
    assert n_test_files == 6 + 4  # 15% of 40 + 15% of 30
