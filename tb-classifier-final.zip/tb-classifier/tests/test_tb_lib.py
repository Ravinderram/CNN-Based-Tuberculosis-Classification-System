import io

import numpy as np
import pytest
from PIL import Image

from tb_lib import (
    IMG_SIZE, CLASS_NAMES, InvalidImageError,
    validate_upload, load_image, preprocess, preprocess_bytes,
    predict_single, interpret_uncertainty,
    confusion_matrix, roc_auc, roc_curve, threshold_sweep,
    best_threshold_for_sensitivity,
    build_heatmap, overlay_heatmap,
)


# --------------------------------------------------------------- helpers

def make_png_bytes(size=(300, 300), color=(120, 120, 120)) -> bytes:
    buf = io.BytesIO()
    Image.new("RGB", size, color).save(buf, format="PNG")
    return buf.getvalue()


# --------------------------------------------------------- preprocessing

def test_validate_upload_rejects_bad_extension():
    with pytest.raises(InvalidImageError, match="Unsupported"):
        validate_upload("scan.txt", b"whatever")


def test_validate_upload_rejects_empty():
    with pytest.raises(InvalidImageError, match="empty"):
        validate_upload("scan.png", b"")


def test_validate_upload_rejects_oversize():
    big = b"x" * (11 * 1024 * 1024)
    with pytest.raises(InvalidImageError, match="too large"):
        validate_upload("scan.png", big)


def test_validate_upload_accepts_good():
    validate_upload("scan.PNG", make_png_bytes())  # case-insensitive ext


def test_load_image_rejects_non_image():
    with pytest.raises(InvalidImageError, match="not a readable image"):
        load_image(b"this is not a png")


def test_preprocess_shape_and_range():
    img = Image.new("RGB", (500, 400), (200, 50, 50))
    arr = preprocess(img)
    assert arr.shape == (1, *IMG_SIZE, 3)
    assert arr.min() >= 0.0 and arr.max() <= 1.0
    assert arr.dtype == np.float32


def test_preprocess_bytes_end_to_end():
    arr = preprocess_bytes("chest.png", make_png_bytes())
    assert arr.shape == (1, *IMG_SIZE, 3)


def test_grayscale_is_converted_to_rgb():
    buf = io.BytesIO()
    Image.new("L", (256, 256), 128).save(buf, format="PNG")  # 1-channel
    arr = preprocess_bytes("gray.png", buf.getvalue())
    assert arr.shape[-1] == 3


# ------------------------------------------------- prediction / MC-dropout

def test_predict_single_deterministic_model():
    # a fake model that always returns 0.8 -> label TB, zero uncertainty
    fn = lambda batch, training: np.array([[0.8]])
    pred = predict_single(fn, np.zeros((1, *IMG_SIZE, 3)), mc_samples=10)
    assert pred.label == CLASS_NAMES[1]
    assert pred.probability == pytest.approx(0.8)
    assert pred.uncertainty_std == pytest.approx(0.0, abs=1e-9)
    assert pred.confidence == pytest.approx(0.8)


def test_predict_single_below_threshold_is_normal():
    fn = lambda batch, training: np.array([[0.2]])
    pred = predict_single(fn, np.zeros((1, *IMG_SIZE, 3)), mc_samples=5)
    assert pred.label == CLASS_NAMES[0]
    assert pred.confidence == pytest.approx(0.8)


def test_mc_dropout_captures_uncertainty():
    # stochastic fake model: outputs vary -> nonzero std + CI width
    rng = np.random.default_rng(0)
    fn = lambda batch, training: np.array([[rng.uniform(0.3, 0.7)]])
    pred = predict_single(fn, np.zeros((1, *IMG_SIZE, 3)), mc_samples=200)
    assert pred.uncertainty_std > 0.05
    assert pred.ci_low < pred.probability < pred.ci_high


def test_predict_rejects_bad_threshold():
    fn = lambda batch, training: np.array([[0.5]])
    with pytest.raises(ValueError):
        predict_single(fn, np.zeros((1, *IMG_SIZE, 3)), threshold=1.5)


def test_interpret_uncertainty_flags_high_spread():
    fn = lambda batch, training: np.array([[np.random.uniform(0, 1)]])
    pred = predict_single(fn, np.zeros((1, *IMG_SIZE, 3)), mc_samples=300)
    msg = interpret_uncertainty(pred)
    assert "uncertainty" in msg.lower() or "caution" in msg.lower() \
        or "consistent" in msg.lower()


def test_prediction_as_dict_has_disclaimer():
    fn = lambda batch, training: np.array([[0.9]])
    pred = predict_single(fn, np.zeros((1, *IMG_SIZE, 3)), mc_samples=3)
    d = pred.as_dict()
    assert "disclaimer" in d and "credible_interval" in d


# ------------------------------------------------------------- metrics

def test_confusion_matrix_perfect():
    y_true = np.array([0, 0, 1, 1])
    y_prob = np.array([0.1, 0.2, 0.8, 0.9])
    cm = confusion_matrix(y_true, y_prob, threshold=0.5)
    assert (cm.tp, cm.fp, cm.tn, cm.fn) == (2, 0, 2, 0)
    assert cm.accuracy == 1.0
    assert cm.precision == 1.0 and cm.recall == 1.0
    assert cm.specificity == 1.0 and cm.f1 == 1.0


def test_confusion_matrix_with_errors():
    y_true = np.array([0, 0, 1, 1])
    y_prob = np.array([0.6, 0.2, 0.8, 0.3])  # one FP, one FN
    cm = confusion_matrix(y_true, y_prob, threshold=0.5)
    assert (cm.tp, cm.fp, cm.tn, cm.fn) == (1, 1, 1, 1)
    assert cm.accuracy == 0.5


def test_roc_auc_perfect_separation():
    y_true = np.array([0, 0, 1, 1])
    y_prob = np.array([0.1, 0.2, 0.8, 0.9])
    assert roc_auc(y_true, y_prob) == pytest.approx(1.0)


def test_roc_auc_random_is_half():
    rng = np.random.default_rng(1)
    y_true = rng.integers(0, 2, 2000)
    y_prob = rng.uniform(0, 1, 2000)
    assert roc_auc(y_true, y_prob) == pytest.approx(0.5, abs=0.05)


def test_roc_curve_endpoints():
    y_true = np.array([0, 1, 0, 1])
    y_prob = np.array([0.2, 0.9, 0.4, 0.7])
    fpr, tpr, _ = roc_curve(y_true, y_prob)
    assert fpr[0] == 0.0 and tpr[0] == 0.0
    assert fpr[-1] == pytest.approx(1.0) and tpr[-1] == pytest.approx(1.0)


def test_threshold_sweep_length_and_bounds():
    y_true = np.array([0, 1, 0, 1])
    y_prob = np.array([0.3, 0.7, 0.4, 0.6])
    sweep = threshold_sweep(y_true, y_prob, steps=11)
    assert len(sweep) == 11
    assert all(0 <= r["accuracy"] <= 1 for r in sweep)


def test_best_threshold_for_sensitivity():
    y_true = np.array([0, 0, 1, 1, 1])
    y_prob = np.array([0.1, 0.4, 0.55, 0.7, 0.9])
    t = best_threshold_for_sensitivity(y_true, y_prob, target_sensitivity=1.0)
    cm = confusion_matrix(y_true, y_prob, threshold=t)
    assert cm.recall == 1.0


# ------------------------------------------------------------- grad-cam

def test_build_heatmap_shape_and_range():
    rng = np.random.default_rng(2)
    fmaps = rng.random((7, 7, 16)).astype(np.float32)
    grads = rng.random((7, 7, 16)).astype(np.float32)
    hm = build_heatmap(fmaps, grads)
    assert hm.shape == (7, 7)
    assert hm.min() >= 0.0 and hm.max() <= 1.0


def test_build_heatmap_relu_clips_negatives():
    # gradients all negative -> weights negative -> cam <= 0 -> ReLU -> zeros
    fmaps = np.ones((4, 4, 3), dtype=np.float32)
    grads = -np.ones((4, 4, 3), dtype=np.float32)
    hm = build_heatmap(fmaps, grads)
    assert np.all(hm == 0.0)


def test_build_heatmap_shape_mismatch_raises():
    with pytest.raises(ValueError):
        build_heatmap(np.zeros((4, 4, 3)), np.zeros((5, 5, 3)))


def test_overlay_heatmap_output():
    image = (np.random.rand(32, 32, 3) * 255).astype(np.uint8)
    heatmap = np.random.rand(8, 8).astype(np.float32)
    out = overlay_heatmap(image, heatmap)
    assert out.shape == (32, 32, 3)
    assert out.dtype == np.uint8
