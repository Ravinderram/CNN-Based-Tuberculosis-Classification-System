"""FastAPI backend for the TB classifier.

Run with:  uvicorn api:app --reload
Docs at:   http://localhost:8000/docs

Security fixes over the original Flask app:
  * No user-controlled filenames written to disk (original saved
    request.files uploads by their own name -> path traversal).
  * Files processed in memory; validated for type and size first.
  * Errors return structured 4xx codes, not raw exception strings.
"""
from __future__ import annotations

import base64
import io

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.responses import JSONResponse

from tb_lib import (
    DISCLAIMER, InvalidImageError, preprocess_bytes, predict_single,
    interpret_uncertainty,
)

app = FastAPI(
    title="TB Chest X-ray Classifier API",
    description=f"CNN-based tuberculosis screening from chest X-rays with "
                f"Monte-Carlo-dropout uncertainty and Grad-CAM. {DISCLAIMER}",
    version="2.0.0",
)


def _load_predict_fn():
    """Lazy: only import TF / load the model when a request needs it."""
    from tb_lib.model import get_predict_fn, ModelNotFoundError
    try:
        return get_predict_fn()
    except ModelNotFoundError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@app.post("/predict")
async def predict(file: UploadFile = File(...)):
    """Classify an uploaded chest X-ray with uncertainty estimates."""
    data = await file.read()
    try:
        batch = preprocess_bytes(file.filename or "upload", data)
    except InvalidImageError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

    predict_fn = _load_predict_fn()
    pred = predict_single(predict_fn, batch)
    result = pred.as_dict()
    result["reliability_note"] = interpret_uncertainty(pred)
    return result


@app.post("/explain")
async def explain(file: UploadFile = File(...)):
    """Return a Grad-CAM overlay (base64 PNG) showing where the model looked."""
    data = await file.read()
    try:
        batch = preprocess_bytes(file.filename or "upload", data)
    except InvalidImageError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

    from tb_lib.gradcam import compute_gradcam, overlay_heatmap
    from tb_lib.model import load_model, ModelNotFoundError
    import numpy as np
    from PIL import Image

    try:
        model = load_model()
    except ModelNotFoundError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc

    heatmap, prob = compute_gradcam(model, batch)
    overlay = overlay_heatmap((batch[0] * 255).astype("uint8"), heatmap)

    buf = io.BytesIO()
    Image.fromarray(overlay).save(buf, format="PNG")
    b64 = base64.b64encode(buf.getvalue()).decode()
    return {
        "probability_tb": round(prob, 4),
        "gradcam_png_base64": b64,
        "disclaimer": DISCLAIMER,
    }


@app.get("/health")
def health():
    return {"status": "ok", "disclaimer": DISCLAIMER}


@app.exception_handler(InvalidImageError)
async def invalid_image_handler(request, exc):
    return JSONResponse(status_code=422, content={"detail": str(exc)})
