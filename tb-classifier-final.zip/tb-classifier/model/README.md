# model/

Trained models live here.

- `legacy_model_v1.h5` — the original from-scratch CNN from v1, kept for
  reference. The v2 pipeline does **not** use it (different architecture,
  input size, and label handling).
- `tb_model.keras` — produced by `scripts/train.py`. Not committed
  (see .gitignore); train it yourself on the TB Chest dataset.
