"""Streamlit UI for the TB classifier — upload OR phone camera.

Run with:  streamlit run app.py

Two input modes:
  * Upload a chest X-ray file (primary, most reliable).
  * Capture with the device camera (bonus; works on mobile browsers via
    st.camera_input). Useful for demoing on a printed/screen X-ray, but
    camera glare/angle degrade reliability — flagged in the UI.

Shows prediction + Monte-Carlo-dropout uncertainty + Grad-CAM.
"""
import numpy as np
import streamlit as st
from PIL import Image

from tb_lib import (
    DISCLAIMER, InvalidImageError, preprocess, preprocess_bytes,
    predict_single, interpret_uncertainty,
)

st.set_page_config(page_title="TB X-ray Classifier", page_icon="🫁",
                   layout="centered")

st.title("🫁 TB Chest X-ray Classifier")
st.warning(f"⚠️ {DISCLAIMER}")
st.caption("Transfer learning (MobileNetV2) · Monte-Carlo-dropout "
           "uncertainty · Grad-CAM explainability. Upload an X-ray, or use "
           "your camera.")


@st.cache_resource(show_spinner=False)
def _get_predict_fn():
    """Load the model once and cache it across reruns. Returns None if absent."""
    try:
        from tb_lib.model import get_predict_fn
        return get_predict_fn()
    except Exception:
        return None


def _analyze(pil_image: Image.Image, from_camera: bool) -> None:
    """Run the full pipeline on a PIL image and render results."""
    try:
        batch = preprocess(pil_image)
    except InvalidImageError as exc:
        st.error(str(exc))
        return

    col_img, col_result = st.columns(2)
    with col_img:
        st.image(pil_image, caption="Input image", use_container_width=True)

    predict_fn = _get_predict_fn()
    if predict_fn is None:
        with col_result:
            st.info("No trained model found yet. Train one with:\n\n"
                    "`python scripts/train.py --data <your_folder>`\n\n"
                    "Then reload this page.")
        return

    if from_camera:
        st.warning("Camera capture: glare, angle, and screen moiré can lower "
                   "reliability — best used only for demonstration.")

    with st.spinner("Running Monte-Carlo-dropout inference..."):
        pred = predict_single(predict_fn, batch)

    with col_result:
        if pred.label == "Tuberculosis":
            st.error(f"### {pred.label}")
        else:
            st.success(f"### {pred.label}")
        st.metric("P(Tuberculosis)", f"{pred.probability:.1%}",
                  f"±{pred.uncertainty_std:.1%} (MC-dropout)")
        st.caption(f"95% interval: [{pred.ci_low:.1%}, {pred.ci_high:.1%}] "
                   f"over {pred.n_samples} stochastic passes")
        st.info(interpret_uncertainty(pred))

    # Grad-CAM
    st.subheader("Where the model looked (Grad-CAM)")
    with st.spinner("Computing Grad-CAM..."):
        from tb_lib.gradcam import compute_gradcam, overlay_heatmap
        from tb_lib.model import load_model
        heatmap, _ = compute_gradcam(load_model(), batch)
        overlay = overlay_heatmap((batch[0] * 255).astype("uint8"), heatmap)
    st.image(overlay, caption="Red = regions driving the prediction",
             use_container_width=True)
    st.caption("Check the model attends to lung fields, not text markers or "
               "borders — a common way medical models cheat.")


tab_upload, tab_camera = st.tabs(["📁 Upload", "📷 Camera"])

with tab_upload:
    uploaded = st.file_uploader("Chest X-ray image",
                                type=["png", "jpg", "jpeg", "bmp"])
    if uploaded is not None:
        try:
            # validate via bytes path (extension + size + decode)
            preprocess_bytes(uploaded.name, uploaded.getvalue())
            img = Image.open(uploaded).convert("RGB")
        except InvalidImageError as exc:
            st.error(str(exc))
        else:
            _analyze(img, from_camera=False)

with tab_camera:
    st.write("Point your camera at a chest X-ray (printed or on screen).")
    shot = st.camera_input("Take a photo")
    if shot is not None:
        img = Image.open(shot).convert("RGB")
        _analyze(img, from_camera=True)
