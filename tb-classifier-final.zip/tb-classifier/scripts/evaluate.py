"""Evaluate a trained TB classifier on the held-out test set.

Usage:
    python scripts/evaluate.py --data /path/to/TB_Chest

Produces:
  * printed metrics (accuracy, precision, recall, specificity, F1, AUC)
  * reports/metrics.json
  * reports/confusion_matrix.png
  * reports/roc_curve.png
  * reports/threshold_sweep.csv

This is the script that turns "it seems to work" into evidence — the
part the original project was missing entirely.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

# Make the `tb_lib` package importable no matter where this script is
# launched from: add the project root (this file's parent's parent) to
# Python's import path before importing tb_lib.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import csv
import json
from pathlib import Path

from tb_lib.config import IMG_SIZE, MODEL_PATH


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--split-dir", default="data_split",
                    help="Dir created by train.py (has test/ inside).")
    ap.add_argument("--model", default=str(MODEL_PATH))
    ap.add_argument("--out", default="reports")
    args = ap.parse_args()

    import numpy as np
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from tensorflow import keras
    from tensorflow.keras.preprocessing.image import ImageDataGenerator

    from tb_lib.metrics import (
        confusion_matrix, roc_curve, roc_auc, threshold_sweep,
        best_threshold_for_sensitivity,
    )

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    model = keras.models.load_model(args.model)
    test = ImageDataGenerator(rescale=1 / 255).flow_from_directory(
        Path(args.split_dir) / "test", target_size=IMG_SIZE, batch_size=32,
        class_mode="binary", classes=["Normal", "Tuberculosis"], shuffle=False,
    )

    y_true = test.classes
    y_prob = model.predict(test).ravel()

    cm = confusion_matrix(y_true, y_prob, threshold=0.5)
    auc = roc_auc(y_true, y_prob)
    thr90 = best_threshold_for_sensitivity(y_true, y_prob, 0.90)

    metrics = cm.as_dict()
    metrics["roc_auc"] = round(auc, 4)
    metrics["threshold_for_90pct_sensitivity"] = thr90
    print(json.dumps(metrics, indent=2))
    (out / "metrics.json").write_text(json.dumps(metrics, indent=2))

    # confusion matrix plot
    m = np.array([[cm.tn, cm.fp], [cm.fn, cm.tp]])
    fig, ax = plt.subplots(figsize=(4, 4))
    ax.imshow(m, cmap="Blues")
    ax.set_xticks([0, 1], ["Pred Normal", "Pred TB"])
    ax.set_yticks([0, 1], ["True Normal", "True TB"])
    for i in range(2):
        for j in range(2):
            ax.text(j, i, m[i, j], ha="center", va="center")
    ax.set_title("Confusion Matrix (threshold=0.5)")
    fig.tight_layout()
    fig.savefig(out / "confusion_matrix.png", dpi=120)

    # ROC curve plot
    fpr, tpr, _ = roc_curve(y_true, y_prob)
    fig, ax = plt.subplots(figsize=(5, 4))
    ax.plot(fpr, tpr, label=f"AUC = {auc:.3f}")
    ax.plot([0, 1], [0, 1], "k--", alpha=0.4)
    ax.set_xlabel("False positive rate")
    ax.set_ylabel("True positive rate (sensitivity)")
    ax.set_title("ROC Curve")
    ax.legend()
    fig.tight_layout()
    fig.savefig(out / "roc_curve.png", dpi=120)

    # threshold sweep csv
    sweep = threshold_sweep(y_true, y_prob, steps=21)
    with open(out / "threshold_sweep.csv", "w", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=["threshold", "accuracy",
                                "precision", "recall_sensitivity",
                                "specificity", "f1"])
        writer.writeheader()
        for row in sweep:
            writer.writerow({k: row[k] for k in writer.fieldnames})

    print(f"\nReports written to {out}/")


if __name__ == "__main__":
    main()
