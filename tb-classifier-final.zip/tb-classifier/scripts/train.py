"""Train the TB classifier — from ONE folder path to a saved model.

The only thing you provide is the path to your raw dataset:

    python scripts/train.py --data /path/to/TB_Chest_Radiography_Database

where that folder contains:

    TB_Chest_Radiography_Database/
        Normal/         *.png
        Tuberculosis/   *.png

The script then automatically:
  1. splits the data into train/val/test (stratified, seeded, 70/15/15);
  2. trains MobileNetV2 (transfer learning) with augmentation +
     class weighting + EarlyStopping/Checkpoint/ReduceLROnPlateau;
  3. saves the best model where the app and API expect it.

Afterwards run:  python scripts/evaluate.py --split-dir <out>/split
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

# Make the `tb_lib` package importable no matter where this script is
# launched from: add the project root (this file's parent's parent) to
# Python's import path before importing tb_lib.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from tb_lib.config import IMG_SIZE, MODEL_PATH
from tb_lib.dataset import auto_split


def main() -> None:
    ap = argparse.ArgumentParser(description="Split + train the TB classifier.")
    ap.add_argument("--data", required=True,
                    help="Path to the raw dataset (Normal/ + Tuberculosis/).")
    ap.add_argument("--work-dir", default="data_split",
                    help="Where the auto-split train/val/test dirs are written.")
    ap.add_argument("--epochs", type=int, default=15)
    ap.add_argument("--batch-size", type=int, default=32)
    ap.add_argument("--dropout", type=float, default=0.3)
    ap.add_argument("--val-frac", type=float, default=0.15)
    ap.add_argument("--test-frac", type=float, default=0.15)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--out", default=str(MODEL_PATH))
    ap.add_argument("--overwrite-split", action="store_true",
                    help="Re-create the split even if work-dir exists.")
    args = ap.parse_args()

    # ---- 1. auto-split from a single folder ---------------------------
    print(f"Splitting {args.data} -> {args.work_dir} (stratified, seed={args.seed})")
    try:
        split_dir, plan = auto_split(
            args.data, args.work_dir,
            val_frac=args.val_frac, test_frac=args.test_frac,
            seed=args.seed, overwrite=args.overwrite_split,
        )
    except FileExistsError:
        print(f"Split dir {args.work_dir} already exists — reusing it. "
              f"(Use --overwrite-split to rebuild.)")
        split_dir = Path(args.work_dir)
    else:
        import json
        print("Split counts:", json.dumps(plan.counts(), indent=2))

    # ---- 2. train (heavy imports happen only now) ---------------------
    import numpy as np
    import tensorflow as tf
    from tensorflow.keras.preprocessing.image import ImageDataGenerator

    from tb_lib.architecture import build_model

    train_gen = ImageDataGenerator(
        rescale=1 / 255, rotation_range=15,
        width_shift_range=0.1, height_shift_range=0.1,
        zoom_range=0.1, horizontal_flip=True,
    )
    eval_gen = ImageDataGenerator(rescale=1 / 255)

    common = dict(target_size=IMG_SIZE, batch_size=args.batch_size,
                  class_mode="binary", classes=["Normal", "Tuberculosis"])
    train = train_gen.flow_from_directory(split_dir / "train", **common)
    valid = eval_gen.flow_from_directory(split_dir / "valid", shuffle=False,
                                         **common)

    counts = np.bincount(train.classes)
    total = counts.sum()
    class_weight = {i: total / (len(counts) * c) for i, c in enumerate(counts)}
    print("Class counts:", counts, "-> weights:", class_weight)

    model = build_model(dropout_rate=args.dropout)
    model.summary()

    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    callbacks = [
        tf.keras.callbacks.EarlyStopping(monitor="val_auc", mode="max",
                                         patience=4, restore_best_weights=True),
        tf.keras.callbacks.ModelCheckpoint(str(out_path), monitor="val_auc",
                                           mode="max", save_best_only=True),
        tf.keras.callbacks.ReduceLROnPlateau(monitor="val_loss", factor=0.5,
                                             patience=2),
    ]
    model.fit(train, validation_data=valid, epochs=args.epochs,
              class_weight=class_weight, callbacks=callbacks)

    print(f"\nSaved best model to {out_path}")
    print(f"Next: python scripts/evaluate.py --split-dir {split_dir}")


if __name__ == "__main__":
    main()
