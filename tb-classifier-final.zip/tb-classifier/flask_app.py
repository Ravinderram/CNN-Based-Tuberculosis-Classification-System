"""Flask app — kept for continuity with the original project.

Now delegates all logic to the tested `tb_lib` package instead of
inlining preprocessing and prediction. Bugs fixed vs. the original:
  * correct model path (config-driven, not the missing
    'pretrained_model.h5')
  * consistent image size (config-driven)
  * uploads validated and processed in memory (no unsafe file writes)
  * structured error responses

Run with:  python flask_app.py
"""
from __future__ import annotations

from flask import Flask, jsonify, render_template, request

from tb_lib import (
    DISCLAIMER, InvalidImageError, preprocess_bytes, predict_single,
    interpret_uncertainty,
)

app = Flask(__name__)


@app.route("/")
def home():
    return render_template("index.html", disclaimer=DISCLAIMER)


@app.route("/predict", methods=["POST"])
def predict():
    file = request.files.get("file")
    if file is None or file.filename == "":
        return jsonify({"error": "No file uploaded"}), 400

    try:
        batch = preprocess_bytes(file.filename, file.read())
    except InvalidImageError as exc:
        return jsonify({"error": str(exc)}), 422

    try:
        from tb_lib.model import get_predict_fn, ModelNotFoundError
        predict_fn = get_predict_fn()
    except ModelNotFoundError as exc:
        return jsonify({"error": str(exc)}), 503

    pred = predict_single(predict_fn, batch)
    payload = pred.as_dict()
    payload["reliability_note"] = interpret_uncertainty(pred)
    return jsonify(payload)


if __name__ == "__main__":
    # debug=False by default: never ship debug=True (original did)
    app.run(debug=False)
